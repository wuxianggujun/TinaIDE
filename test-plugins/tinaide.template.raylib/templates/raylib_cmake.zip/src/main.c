#include <math.h>
#include <raylib.h>

// raylib 在 Android 上由 IDE 的 NativeActivity 宿主加载：
// 宿主先 dlopen 依赖和本库，再解析出这里的 main 并调用它。
// 所以这里写普通的 main 就够了，不需要 android_main，也不要引 SDL 头。
int main(void) {
    InitWindow(0, 0, "{{PROJECT_NAME}}");
    SetTargetFPS(60);

    float phase = 0.0f;

    while (!WindowShouldClose()) {
        phase += 0.02f;

        const int width = GetScreenWidth();
        const int height = GetScreenHeight();
        const float radius = (float)(width < height ? width : height) * 0.18f;
        const float centerX = (float)width * 0.5f + sinf(phase) * (float)width * 0.2f;
        const float centerY = (float)height * 0.5f;

        BeginDrawing();
        ClearBackground(RAYWHITE);
        DrawCircleV((Vector2){centerX, centerY}, radius, MAROON);
        DrawText("raylib on TinaIDE", 24, 24, 28, DARKGRAY);
        DrawFPS(24, 64);
        EndDrawing();
    }

    CloseWindow();
    return 0;
}
