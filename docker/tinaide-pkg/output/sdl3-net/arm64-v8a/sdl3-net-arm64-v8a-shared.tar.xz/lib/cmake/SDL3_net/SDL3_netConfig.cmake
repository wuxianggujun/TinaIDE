# sdl3_net cmake project-config input for CMakeLists.txt script

include(FeatureSummary)
set_package_properties(SDL3_net PROPERTIES
    URL "https://www.libsdl.org/projects/SDL_net/"
    DESCRIPTION "SDL_net is a simple, cross-platform wrapper over sockets"
)

set(SDL3_net_FOUND ON)

set(SDLNET_SDL3_REQUIRED_VERSION  3.0.0)

if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/SDL3_net-shared-targets.cmake")
    include("${CMAKE_CURRENT_LIST_DIR}/SDL3_net-shared-targets.cmake")
endif()

if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/SDL3_net-static-targets.cmake")
    include("${CMAKE_CURRENT_LIST_DIR}/SDL3_net-static-targets.cmake")
endif()

function(_sdl_create_target_alias_compat NEW_TARGET TARGET)
    if(CMAKE_VERSION VERSION_LESS "3.18")
        # Aliasing local targets is not supported on CMake < 3.18, so make it global.
        add_library(${NEW_TARGET} INTERFACE IMPORTED)
        set_target_properties(${NEW_TARGET} PROPERTIES INTERFACE_LINK_LIBRARIES "${TARGET}")
    else()
        add_library(${NEW_TARGET} ALIAS ${TARGET})
    endif()
endfunction()

# Make sure SDL3_net::SDL3_net always exists
if(NOT TARGET SDL3_net::SDL3_net)
    if(TARGET SDL3_net::SDL3_net-shared)
        _sdl_create_target_alias_compat(SDL3_net::SDL3_net SDL3_net::SDL3_net-shared)
    else()
        _sdl_create_target_alias_compat(SDL3_net::SDL3_net SDL3_net::SDL3_net-static)
    endif()
endif()
