/* #undef SDL_VENDOR_INFO */
#define SDL_REVISION_NUMBER 0

#ifdef SDL_VENDOR_INFO
#define SDL_REVISION "SDL-release-2.32.10-0-g5d24957 (" SDL_VENDOR_INFO ")"
#else
#define SDL_REVISION "SDL-release-2.32.10-0-g5d24957"
#endif
