include(FeatureSummary)
set_package_properties(SDL2_net PROPERTIES
    URL "https://www.libsdl.org/projects/SDL_net/"
    DESCRIPTION "SDL_net is an example portable network library for use with SDL."
)

set(SDL2NET_SDL2_REQUIRED_VERSION  2.0.4)

include(CMakeFindDependencyMacro)

set(SDL2_net_FOUND FALSE)
#FIXME: can't add SDL2NET_SDL2_REQUIRED_VERSION since not all SDL2 installs ship SDL2ConfigVersion.cmake
if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/SDL2_net-shared-targets.cmake")
    include("${CMAKE_CURRENT_LIST_DIR}/SDL2_net-shared-targets.cmake")
    set(SDL2_net_FOUND TRUE)
endif()

if(EXISTS "${CMAKE_CURRENT_LIST_DIR}/SDL2_net-static-targets.cmake")
    include("${CMAKE_CURRENT_LIST_DIR}/SDL2_net-static-targets.cmake")
    set(SDL2_net_FOUND TRUE)
endif()
